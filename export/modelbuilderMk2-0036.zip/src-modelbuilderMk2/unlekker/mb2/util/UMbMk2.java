package unlekker.mb2.util;

/**
 * Hack to provide legacy support for the name-change from
 * UBase to UMbMk2 and then finally to UMB.
 * 
 * @author marius
 *
 */
public class UMbMk2 extends UMB {

}
