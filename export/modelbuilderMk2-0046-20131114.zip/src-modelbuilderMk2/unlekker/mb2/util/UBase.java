package unlekker.mb2.util;

/**
 * Hack to provide legacy support for the name-change from
 * UBase to UMB.
 * 
 * @author marius
 *
 */
public class UBase extends UMB {

}
