package unlekker.mb2.util;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import unlekker.mb2.geo.UEdge;

public class UFileStructure extends UMB {
  public boolean isFile;
  public String path;
  public ArrayList<UFileStructure> dir,files;
  public UFileThread thread;
  
  public Date modified;
  public String filename,ext;
  public long b,kb;
  
  public UFileStructure(String path) {
    this.path=path;
  }
  
  public UFileStructure(File file) {
    isFile=file.isFile();
    path=file.getAbsolutePath();
    
    long t=file.lastModified();
    modified=new Date(t);
    
    if(isFile) {
      filename=UFile.noPath(path);
      ext=UFile.getExt(filename);
      
      b=file.length();
      kb=b/1024;
    }
  }
  
  public boolean equals(Object o) {
    if(path==null) {
      log("THIS PATH NULL");
      return false;
    }
    UFileStructure d2=(UFileStructure)o;
    return (d2.path.compareTo(path)==0);
  }

  public UFileStructure process() {
    dir=new ArrayList<UFileStructure>();
    files=new ArrayList<UFileStructure>();
    
    try {
      File[] f=new File(path).listFiles();
      long filesTotal=0;
      
      if(f!=null) {
        for(File file:f) {
          if(file.isDirectory()) dir.add(new UFileStructure(file));
          else {
            UFileStructure ff=new UFileStructure(file);
            files.add(ff);
            filesTotal+=ff.b;
          }
        }
      }
      
      b=filesTotal;
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
//    logf("processed: %s\n%d %d",path,dir.size(),files.size());
    
    logDivider(path);
    if(dir.size()>0) {
      log("---dir");
      log(str(dir));
      
    }
    if(files.size()>0) {
      log("---files");
      log(str(files));
    }
    return this;    
  }
  
  public UFileStructure recurse() {
    thread=new UFileThread(this);
    new Thread(thread).start();
    
    return this;
  }

  public int[] getFileCount() {
    int cnt[]=new int[] {dir.size(),files.size()};
    
    for(UFileStructure d:dir) {
      int[] tmp=d.getFileCount();
      cnt[0]+=tmp[0];
      cnt[1]+=tmp[1];
    }
    
    return cnt;
  }
  
  public void getData(ArrayList<String> out,int level) {
    String indent="";
    if(level>-1) {
      for(int i=0; i<level; i++) indent+="  ";
    }
    
    out.add(indent+"-----------");
    out.add(indent+strf("--%s\td=%d\tf=%d\tbytes=%d",
        path,dir.size(),files.size(),b));
    for(UFileStructure d:dir) out.add(indent+d.toString());
    for(UFileStructure f:files) out.add(indent+f.toString());
    for(UFileStructure d:dir) d.getData(out,level+1);    
  }

  public ArrayList<String> getData() {
    ArrayList<String> out=new ArrayList<String>();
    
    int[] cnt=getFileCount();
    out.add("DIR="+cnt[0]+" FILES="+cnt[1]);
    getData(out,0);
    return out;
  }
  
  public String toString() {
    String tstr=dateStr(modified)+"\t"+modified.getTime();
    if(isFile) {
      return "F\t"+filename+"\t"+b+"\t"+tstr;
      
    }
    
    return "D\t"+path+"\t"+tstr;
  }
  
  
  public class UFileThread implements Runnable {
    UFileStructure parent;
    public ArrayList<UFileStructure> queue;
    public boolean done;
    public int processed=0;
    
    public UFileThread(UFileStructure parent) {
      this.parent=parent;
      queue=new ArrayList<UFileStructure>();
      add(parent);
    }
    
    public boolean done() {
      return done;
    }
    
    public void add(UFileStructure f) {
      if(queue.size()>0 && queue.indexOf(f)>-1) return;
      queue.add(f);
    }
    
    public void run() {
      while(queue.size()>0) {
        UFileStructure curr=queue.get(0);
        
        curr.process();
        if(curr.dir!=null)
          for(UFileStructure d:curr.dir) add(d);
        processed++;
        
        queue.remove(0);
      }
      
      done=true;
    }
    
  }

}
