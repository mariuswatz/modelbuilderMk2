package unlekker.mb2.data;

import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.http.*;
import org.apache.http.ProtocolException;
import org.apache.http.client.*;
import org.apache.http.client.params.*;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.impl.client.*;
import org.apache.http.protocol.HttpContext;

import unlekker.mb2.util.UConfig;
import unlekker.mb2.util.UMB;

public class UAPITool extends UMB implements Runnable {
  public Thread thread;
  
  public Map<String,String> params = new HashMap<String,String>( );
  public String APIKEY,BASEURL;
  
  public ArrayList<String> result;
  
  private HttpClient httpClient;
  URL url;
  Date date,date2;
  
  int state=APINOTSTARTED;

  
  public UAPITool(UConfig conf) {
    state=APINOTSTARTED;
    BASEURL=conf.get("BASEURL");
    APIKEY=conf.get("APIKEY");
    
    ArrayList<String> keys=conf.getKeys();
    for(String key:keys) {
      if(!(key.compareTo("BASEURL")==0 || key.compareTo("APIKEY")==0)) {
        addParam(key, conf.get(key));
      }
    }
  }
    
  public UAPITool addParam(String key,String val) {
    params.put(key,val);
    return this;
  }
  
  SimpleDateFormat DateFormat=new SimpleDateFormat("YYYY-MM-dd");
  

  public void run(Date d1,Date d2,Map<String,String> params) {
    
  }

  private HttpClient createHttpClient( ) {
    DefaultHttpClient httpClient = new DefaultHttpClient( );

    httpClient.getParams( ).setParameter( ClientPNames.COOKIE_POLICY, CookiePolicy.BROWSER_COMPATIBILITY );
    httpClient.setRedirectStrategy( new DefaultRedirectStrategy( ) {
      @Override
      public boolean isRedirected( HttpRequest request, HttpResponse response, HttpContext context ) throws ProtocolException {
        int responseCode = response.getStatusLine( ).getStatusCode( );
        return super.isRedirected( request, response, context ) || responseCode == 301 || responseCode == 302;
      }
      
    } );
      

    return httpClient;
  }

  private void buildUrl()  {
    
    String s=BASEURL;
    
    Iterator it = params.entrySet().iterator();
    
    int cnt=0;
    while(it.hasNext()) {
      Map.Entry pairs = (Map.Entry)it.next();

      String tmp=pairs.getKey()+"="+pairs.getValue();
      s+=((cnt++)==0 ? "?" : "&")+tmp;
    }

    try {
      url=new URL(s);
    } catch (MalformedURLException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
      url=null;
    }
  }


  /**
   *   public String APIKEY="B63VmJJTpolCM8Y1BH1LvjJfSbA6uPV3e1XGeQ1Q";
  = "https://www.rescuetime.com/anapi/data"
      //https://www.rescuetime.com/anapi/data?rtapi_key=yourAPIkey&perspective=interval&format=csv&resolution_time=hour&restrict_kind=activity&restrict_begin=2009-01-01&restrict_end=2009-12-31

   */
  
  public void run() {
    // TODO Auto-generated method stub
    
  }
  
  
}
