package unlekker.mb2.data;

import java.util.ArrayList;

public class UDataCategory extends UDataPoint {
  public String name;
  
  public ArrayList<UDataPoint> data=new ArrayList<UDataPoint>();
  
  public UDataCategory(String key) {
    name=key;
  }

  public UDataCategory add(UDataPoint pt) {
    data.add(pt);
    if(pt.categories().indexOf(this)<0) pt.addCategory(this);
    return this;
  }
  
}
