package unlekker.mb2.data;

import java.util.ArrayList;

import unlekker.mb2.util.UMB;

public class UDataPoint extends UMB {
  UTimestamp t; 
  public ArrayList<UDataCategory> category=new ArrayList<UDataCategory>();
  
  ArrayList<Float> valF;
  ArrayList<Integer> valI;
  ArrayList<String> valStr;
  
  public UDataPoint() {
  }
  
  public UDataPoint(long t) {
    this.t=new UTimestamp(t);
  }

  public UDataPoint addCategory(UDataCategory cat) {
    if(category.indexOf(cat)<0) category.add(cat);
    return this;
  }
  
  public UDataPoint add(float f) {
    if(valF==null) valF=new ArrayList<Float>();
    valF.add(f);
    return this;
  }

  public UDataPoint add(int i) {
    if(valI==null) valI=new ArrayList<Integer>();
    valI.add(i);
    return this;
  }

  public UDataPoint add(String str) {
    if(valStr==null) valStr=new ArrayList<String>();
    valStr.add(str);
    return this;
  }

  public ArrayList<Integer> dataInt() {
    return valI;
  }

  public ArrayList<Float> dataFloat() {
    return valF;
  }

  public ArrayList<UDataCategory> categories() {
    return category;    
  }
}
