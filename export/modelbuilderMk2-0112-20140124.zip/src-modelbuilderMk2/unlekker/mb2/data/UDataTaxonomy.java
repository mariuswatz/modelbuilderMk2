package unlekker.mb2.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

import unlekker.mb2.util.UMB;

public class UDataTaxonomy extends UMB implements Iterable<UDataCategory> {
  public HashMap<String,UDataCategory> map;
  
  public UDataTaxonomy() {
    map=new HashMap<String, UDataCategory>();
  }
  
  public UDataCategory get(String key) {
    return (map.containsKey(key) ? map.get(key) : null);
  }

  public UDataCategory add(String key) {
    UDataCategory cat=get(key);
    if(cat==null) {
      cat=new UDataCategory(key);
      map.put(key, cat);
    }
    
    return cat;
  }

  @Override
  public Iterator<UDataCategory> iterator() {
    return new UDataCategoryIterator();
  }

  public class UDataCategoryIterator implements Iterator<UDataCategory> {
    int id=-1;
    Iterator<String> it;
    ArrayList<String> keys;

    public UDataCategoryIterator() {
      keys= new ArrayList(map.keySet());
      Collections.sort(keys);
      
      it=keys.iterator();
    }
    
    public boolean hasNext() {
      return it.hasNext();
    }

    public UDataCategory next() {
      return get(it.next());
    }

    @Override
    public void remove() {
      
      
    }
    
  }
}
