package unlekker.mb2.data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import unlekker.mb2.util.UMB;

public class UTimestamp extends UMB {
  long t;
  Calendar cal;
  
  static ArrayList<SimpleDateFormat> dateFormats;
  
  static { 
    dateFormats=new ArrayList<SimpleDateFormat>();
    dateFormats.add(new SimpleDateFormat("EEE, d MMM yy HH:mm:ss Z",Locale.US));
    dateFormats.add(new SimpleDateFormat("yyyy-mm-dd HH:mm:ss",Locale.US));
    dateFormats.add(new SimpleDateFormat("yyyymmdd HH:mm:ss",Locale.US));
    dateFormats.add(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US));    
  };
  
  public UTimestamp(String timestr) {
    t=parseLong(timestr);    
  }

  public UTimestamp(long t) {
    this.t=t;    
  }

  public double timelinePos(UTimestamp t1,UTimestamp t2) {
    long tD=(t2.t>t1.t ? t2.t-t1.t : t1.t-t2.t);
    long tmpT=(t2.t>t1.t ? t-t1.t : t-t2.t);
    double T=map(tmpT, 0, tD-1, 0, 1d);

    return T;
  }
  
  public static long parseLong(String input) {
    long res=Long.MIN_VALUE;
    
    if(input.indexOf(' ')==-1) try {
      res=Long.parseLong(input);
      return res;
    }catch (Exception e) {res=Long.MIN_VALUE;} 

    for(SimpleDateFormat df:dateFormats) {
      try {
        res=df.parse(input).getTime();
        return res;
      }catch (Exception e) {res=Long.MIN_VALUE;} 
    }
    
    if(res==Long.MIN_VALUE) {
      logErr("UTimestamp.parseLong failed: "+input);
      res=0;
    }
    
    return res;
  }
}
