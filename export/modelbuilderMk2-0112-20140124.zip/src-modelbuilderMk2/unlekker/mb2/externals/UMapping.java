package unlekker.mb2.externals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

import processing.data.*;
import unlekker.mb2.geo.UVertex;
import unlekker.mb2.geo.UVertexList;
import unlekker.mb2.util.UMB;

public class UMapping extends UMB {
  UVertexList vl;
  
  public ArrayList<UGeoLocation> loc;
  SimpleDateFormat dfFoursquare=new SimpleDateFormat("EEE, d MMM yy HH:mm:ss Z",Locale.US);
  SimpleDateFormat dfOpenPaths=new SimpleDateFormat("yyy-mm-dd HH:mm:ss",Locale.US);

  public UMapping() {
    loc=new ArrayList<UMapping.UGeoLocation>();
  }

  /**
   * Expects String[4], in order: Name, Date,lon,lat
   * @param input
   */
  public void add(String input[]) {
    long T=Long.MIN_VALUE;
    try {      
      T=dfFoursquare.parse(input[1]).getTime();
    } catch (ParseException e) {
      // TODO Auto-generated catch block
      T=Long.MIN_VALUE;
    }
      
    if(T==Long.MIN_VALUE) try {      
      T=dfOpenPaths.parse(input[1]).getTime();
    } catch (ParseException e) {
      // TODO Auto-generated catch block
      T=Long.MIN_VALUE;
    }
      
    
    if(T==Long.MIN_VALUE) try {
      T=Long.parseLong(input[1]);
    } catch (NumberFormatException e) {
      // TODO Auto-generated catch block
      T=Long.MIN_VALUE;
      e.printStackTrace();
    } 
    
      add(input[0],T,
          Float.parseFloat(input[2]),
          Float.parseFloat(input[3]));
  }

  public UVertexList getPointList() {
    if(vl!=null) vl.clear();
    else vl=new UVertexList();
    vl.enable(NOCOPY);
    
    for(UGeoLocation tmp:loc) vl.add(tmp.coord);
    return vl;
  }
  
  public void add(String name,long T,float lon,float lat) {
    loc.add(new UGeoLocation(name, T, new UVertex(lat,lon)));
  }
  
  static public UMapping parseFoursquare(String filename) {
    UMapping dat=new UMapping();
   
    try {
      XML rss = getPApplet().loadXML(filename);
      
      
      // Get all items
      XML[] items = rss.getChildren("channel/item");
      for (int i = 0; i < items.length; i++) {
        XML data=items[i];
        
        XML geoRSSXML = data.getChild("georss:point");
        String tok[]=getPApplet().split(geoRSSXML.getContent()," ");
        
        String str[]=new String[] {
            data.getChild("title").getContent(),
            data.getChild("pubDate").getContent(),
            tok[1],tok[0]
        };
        
        dat.add(str);
      }
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    int cnt=0;
    for(UGeoLocation l:dat.loc) {
      Calendar c=Calendar.getInstance();
      c.setTimeInMillis(l.timestamp);
      log((cnt++)+" "+l.name+" "+c.getTime().toString());
    }
    
    return dat;
  }
  
  static public UVertex mercatorMapping(UVertex pt,UVertex geobb[],float w,float h) {
    UVertex res=new UVertex();
    
    float lat=pt.x;
    float lon=pt.y;
    
    res.set(pt);//.mult(DEG_TO_RAD);
    
    res.x=w * (lon*DEG_TO_RAD-geobb[0].y*DEG_TO_RAD) / ((geobb[1].y*DEG_TO_RAD-geobb[0].y*DEG_TO_RAD));
    
//      return new PVector(getScreenX(longitudeInDegrees), getScreenY(latitudeInDegrees));

    
    float scRelY=(float)Math.log(
        Math.tan(lat /360f*PI + Math.PI / 4d));

    float topLatRel=(float)Math.log(
        Math.tan(geobb[0].x/360f*PI + Math.PI / 4d));
    float bottomLatRel=(float)Math.log(
        Math.tan(geobb[1].x/360f*PI + Math.PI / 4d)
    );
//    getScreenY
//      mapScreenHeight * (getScreenYRelative(latitudeInDegrees) - topLatitudeRelative) / (bottomLatitudeRelative - topLatitudeRelative);    res.y=
    
//    res.y=h*(scRelY-geobb[0].y*DEG_TO_RAD)/
//        (geobb[1].y*DEG_TO_RAD - geobb[0].y*DEG_TO_RAD);
    
    res.y=(scRelY-topLatRel)/(bottomLatRel-topLatRel);
    res.y*=h;
    
    return res;
  }
  
  static public UMapping parseOpenPathsCSV(String filename) {
    UMapping dat=new UMapping();
   
    try {
      // lat,lon,alt,timestamp,device,os,version
      Table tab=getPApplet().loadTable(filename,"header");
      
      for(TableRow r:tab.rows()) {
        String str[]=new String[] {
            r.getString(4),
            r.getString(3),
            r.getString(0),
            r.getString(1)
        };
        dat.add(str);
        
      }
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    int cnt=0;
    for(UGeoLocation l:dat.loc) {
      Calendar c=Calendar.getInstance();
      c.setTimeInMillis(l.timestamp);
      log((cnt++)+" "+l.name+" "+c.getTime().toString());
    }
    
    return dat;
  }
  
  public class UGeoLocation {
    public UVertex coord;
    public String name;
    public long timestamp;
    
    
    public UGeoLocation(String name,long t, UVertex coord) {
      this.name=name;
      this.coord=coord;
      this.timestamp=t;
    }
  }
  
}
