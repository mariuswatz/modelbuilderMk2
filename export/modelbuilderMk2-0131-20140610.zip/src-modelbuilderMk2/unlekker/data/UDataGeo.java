package unlekker.data;

import unlekker.mb2.util.UMB;

/**
 * - Place or track
 * - Type 
 * -
 * 
 * @author marius
 *
 */
public class UDataGeo extends UDataPoint {

 
}
