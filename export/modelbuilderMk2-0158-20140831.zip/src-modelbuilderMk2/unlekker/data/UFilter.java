package unlekker.data;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Comparator;

public class UFilter<T> implements Comparator<T> {

  public boolean accept(T o) {
    return true;
  }

  public int compare(T o1, T o2) {
    // TODO Auto-generated method stub
    return 0;
  }

}
