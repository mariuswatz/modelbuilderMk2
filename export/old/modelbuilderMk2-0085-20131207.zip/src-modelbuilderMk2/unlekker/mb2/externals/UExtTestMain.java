package unlekker.mb2.externals;

import java.util.ArrayList;

import processing.core.PApplet;
import unlekker.mb2.util.UMB;
import unlekker.mb2.geo.*;
import geomerative.*;

public class UExtTestMain extends PApplet {
  RShape shp;

  RShape polyshp;
  RPolygon poly;
  RMesh mesh;

  String path="C:/Users/marius/Dropbox/03 Code/ITP2013Parametric/nosync/data/";
  String filename="testB.svg";

  UNav3D nav;
  ArrayList<UVertexList> sl=new ArrayList<UVertexList>();
  UGeo geo,geo2;
  
  public void setup(){
    size(600, 600,OPENGL);
    smooth();
    
    UMB.setPApplet(this);
    nav=new UNav3D();
    
    // VERY IMPORTANT: Allways initialize the library before using it
    RG.init(this);


    if(geo==null) build();
    
    
  }

  public void draw(){
    background(255);

    translate(width/2,height/2);
    nav.doTransforms();


    noFill();
    stroke(0);
    
    if(mousePressed) {
      int cnt=0;
      for(UVertexList tmp:sl) if(tmp.size()>10) {
        stroke(((cnt++)*10)%155+100);
        tmp.draw();
        for(UVertex vv:tmp) UMB.pellipse(vv,3);
      }
    }
    else {
      fill(0,255,255);
      
      if(keyEvent!=null && keyEvent.isShiftDown()) {
        geo2.draw().drawVertexNormals(10);
        geo.drawVertexNormals(10);
      }
      else geo.draw();
    }
//    RG.shape(polyshp);
  }

  public void keyPressed( ) {
    if(key!=CODED && key!=ESC) build();
  }

  void build() {
    filename="my_tile2.svg";
    shp = RG.loadShape(path+filename);
    shp = RG.centerIn(shp, g, 100);
    UVertexList vl,vl2;
    vl=new UVertexList();
    for(int i=0; i<5; i++) vl.add(i,0);
    
    vl.close();
    vl.insert(2, vl.get(1));
    println(UMB.str(vl.removeDuplID()));

    println(vl.str());

      // We decided the separation between the polygon points dependent of the mouseX
    float pointSeparation = map(constrain(mouseX, 100, width-100), 
        100, width-100, 4, 200);

//     We create the polygonized version
    RG.setPolygonizer(RG.UNIFORMLENGTH);
    RG.setPolygonizerLength(pointSeparation);

    polyshp = RG.polygonize(shp);
    poly=polyshp.toPolygon();
    mesh=polyshp.toMesh();
    
    geo=new UGeo().triangleFan(UVertexList.circle(200, 30));
    geo=UGeomerative.fromRMesh(RG.loadShape(path+"testB.svg").toMesh());
    geo.extrudeSelf(30, true);
    geo.removeDuplV().regenerateFaceData();
    geo.writeSTL(path+"test1.stl");


    geo2=UGeomerative.fromRMesh(mesh);
    geo=geo2.copy();
    geo.extrudeSelf(50, true);
    geo.getV().mergeClose(0.15f);
    geo.removeDuplV();
//    geo.taint();
    
    println(geo.str());
    geo.writeSTL(path+filename+".stl");
    
    sl=UGeomerative.fromRStrip(mesh.strips);
  }
  
  public static void main(String[] args) {
    PApplet.main("unlekker.mb2.externals.UExtTestMain");

  }

}
