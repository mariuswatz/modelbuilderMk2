package unlekker.mb2.externals;

import java.util.ArrayList;

import unlekker.mb2.util.UMB;
import unlekker.mb2.geo.*;
import geomerative.*;

public class UGeomerative extends UMB {

  static public UGeo fromRMesh(RMesh mesh) {
    UGeo geo=new UGeo();
    
    ArrayList<UVertexList> sl=getStrips(mesh);
    for(UVertexList tmp:sl) {
//      tmp.mergeClose(0.1f);
      geo.beginShape(TRIANGLE_STRIP);
      geo.vertex(tmp);
      geo.endShape();
    }
    log("Pre: "+geo.str());
//    geo.getV().mergeClose(0.1f);
    
    geo.removeDuplV();
    
    log("Post: "+geo.str());
    return geo;
  }

  static public UVertexList fromRStrip(RStrip strip) {
    return fromRPoint(strip.getPoints());
  }

  static public ArrayList<UVertexList> getStrips(RMesh mesh) {
    return fromRStrip(mesh.strips);
  }

  static public ArrayList<UVertexList> fromRStrip(RStrip strips[]) {
    ArrayList<UVertexList> sl=new ArrayList<UVertexList>();
    for(RStrip tmp:strips) {
      UVertexList s=fromRStrip(tmp);
//      String ss="";
//      for(UVertex vv:s) ss+=vv.y+"\t";
//      logDivider("\n"+ss);
     sl.add(s);
    } 
    
    UVertexList last=null;
    int cnt=0;
    
    for(UVertexList l:sl) {
      if(last!=null) {
        for(UVertex tmp:last) {
          for(UVertex t2:l) {
            float d=t2.distSq(tmp);
            if(d<0.1f) t2.set(tmp);
          }
        }
      }
      last=l;
    }
    
    
//    log(sl.size()+" strips");
    return sl;
  }


  static public UVertexList fromRPoint(RPoint pt[]) {
    UVertexList vl=new UVertexList();
    for(RPoint tmp:pt) vl.add(tmp.x,tmp.y);  
    return vl;
  }

  static public UVertex fromRPoint(RPoint pt) {
    return new UVertex(pt.x,pt.y);
  }

}
