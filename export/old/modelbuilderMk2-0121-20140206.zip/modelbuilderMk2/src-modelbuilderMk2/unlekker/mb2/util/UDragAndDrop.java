package unlekker.mb2.util;

import java.awt.dnd.*;
import java.awt.datatransfer.*;

public class UDragAndDrop extends UMB implements DropTargetListener {

  
  public UDragAndDrop() {
    if(checkPAppletSet()) {
//      getPApplet().setD
    }
  }

  @Override
  public void dragEnter(DropTargetDragEvent dtde) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void dragOver(DropTargetDragEvent dtde) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void dropActionChanged(DropTargetDragEvent dtde) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void dragExit(DropTargetEvent dte) {
    // TODO Auto-generated method stub
    
  }

  @Override
  public void drop(DropTargetDropEvent dtde) {
    // TODO Auto-generated method stub
    
  }
}
